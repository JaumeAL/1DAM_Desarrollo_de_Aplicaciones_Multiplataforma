/* {
    "name": "Jaume Albert",
    "surnames": "Salas Pastor",
    "age": "18"
    }
 */
package es.cide.dam.programacio.yaaz;

public class constantesProbabilidades {
    //Probabilidades de aparición de los artefactos en novaCiutat
    public static final int armaDeFoc = 1; //Probabilidad de 1/10
    public static final int armaDAcer = 4; //Probabilidad de 4/10
    public static final int FARMACIOLA = 9; //Probabilidad de 9/10
    public static final int ESCUD = 19; //Probabilidad de 19/10

}
