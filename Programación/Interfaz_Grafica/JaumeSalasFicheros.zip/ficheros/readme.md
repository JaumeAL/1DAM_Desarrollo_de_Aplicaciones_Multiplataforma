# Editor de Fitxers de Text
![Vista previa](vista.png)
